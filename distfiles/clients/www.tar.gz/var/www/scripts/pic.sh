#!/bin/sh
for i in `seq 1 5`; do
	sudo libcamera-still -t 100 -n -o /var/www/html/images/now.jpg &
	sleep 11
done

