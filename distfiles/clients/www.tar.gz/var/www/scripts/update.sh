#!/bin/sh
cd /var/www/scripts
rm -f version.txt
wget -nc -q --no-check-certificate https://iotserver.example.jp/download/version.txt || exit 100
diff -s version.txt version.txt.now && exit 150
mv -f version.txt version.txt.orig
rm -f update.tar.gz
wget -nc -q -P /var/www/scripts/ --no-check-certificate https://iotserver.example.jp/download/update.tar.gz || exit 200
tar --overwrite -C /var/www/html/ -x -z -f /var/www/scripts/update.tar.gz || exit 250
mv -f version.txt.orig version.txt.now
return $?
