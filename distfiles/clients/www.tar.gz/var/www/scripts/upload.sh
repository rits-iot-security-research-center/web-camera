#!/bin/sh

d=$(date "+%Y%m%d_%H%M%S")
raspistill -t 100 -o /var/www/html/images/now.jpg
exec ftp -n < /var/www/scripts/ftpcmd.txt
