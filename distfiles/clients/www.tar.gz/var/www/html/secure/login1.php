<?php
  // 表示メッセージ
  $message = "";

  // ログインボタンを押された時の処理（成功時は管理画面へリダイレクト）
  // 演習教材ではセッション有無に関係なくログイン処理を行う
  if(($_SERVER['REQUEST_METHOD'] == 'POST') && (isset($_POST['command']))) {
    if($_POST['command'] == "ログイン") {

      if((isset($_POST["username"])) && (isset($_POST["password"]))) {

        // 脆弱性ポイント：外部入力値をそのまま使用してSQL文を組み立てている。
        // 修正アドバイス：プレースホルダを利用する。(外部入力値以外でも想定していない値で
        // 　　　　　　　　リテラルが壊れることもあるため、全てのSQL文で利用すること)
        //$data= "SELECT * FROM user WHERE id = \"".$_POST["username"]."\" AND passwd = \"".$_POST["password"]."\"";
        //$db = new SQLite3('/var/www/db/user1.db');
        //$result = $db->query($data);
        //$result1 = $result->fetchArray();

        // 修正サンプル
        $opt = array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION);
	$db = new PDO("sqlite:/var/www/db/user1.db");
        $sql = "SELECT * FROM user WHERE id = ? AND passwd = ? ";
        $ps = $db->prepare($sql);
        $ps->bindValue(1,$_POST["username"]);
	$ps->bindValue(2,$_POST["password"]);
	$ps->execute();
	$result1 = $ps->fetch();

        // ログイン成功
        if($result1 != NULL) {
          // 脆弱性ポイント：セッションIDを再生成していないので、セッション固定攻撃が可能。
          // 修正アドバイス：セッションIDを新しい値にする（session_regenerate_id()関数など）。
          session_start();
          $_SESSION['username'] = $_POST["username"];
          header("Location: update.php", TRUE, 302);
          exit;
        }
      }

      // ログイン失敗(パラメータ不足か誤り)
      $message = "ユーザ名またはパスワードが違います。";
    }
  } // ログインボタンを押された時の処理 ここまで
?>

<!DOCTYPE html>
<html lang="ja">
<head>
<meta charset="utf-8">
<title>管理者用ログイン画面</title>
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<link rel="stylesheet" href="common.css">
</head>

<body>
    <header class=admin>
        <h1>管理者用ページ</h1>
    </header>

    <div >
      ログインが必要です。
      <p class=message>
	      <?php echo $message; ?>
      </p>
      <hr>
      <table>
        <form method="POST" action="login1.php">
          <tr>
            <th>ユーザ名：</th>
            <td>
              <input type="text" name="username" value="" size="24">
            </td>
          </tr>
          <tr>
            <th>パスワード：</th>
            <td>
              <input type="password" name="password" value="" size="24">
            </td>
          </tr>
          <tr>
            <td colspan="2">
              <input type="submit" name="command" value="ログイン">
            </td>
          </tr>
        </form>
      </table>
      
            <br>
            <hr>
            <div class=submenu>
              <a href="index.html">一般用のページに戻る</a>
            </div>
    </div>
</body>
</html>