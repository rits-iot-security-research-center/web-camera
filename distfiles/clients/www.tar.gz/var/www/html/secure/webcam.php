<?php
  // クライアント情報(外部入力だが一切チェックせずにそのまま使用している)
  $from_ip = isset($_SERVER['REMOTE_ADDR'])? $_SERVER['REMOTE_ADDR'] : '情報なし';
  $from_host = isset($_SERVER['REMOTE_HOST'])? $_SERVER['REMOTE_HOST'] : '情報なし';
  $from_agent = isset($_SERVER['HTTP_USER_AGENT'])? $_SERVER['HTTP_USER_AGENT'] : '情報なし';

  // バージョン情報
  $html = file_get_contents("index.html");
  $version = "情報なし";
  if($html) {
    $pattern = '/<version>(.*)<\/version>/';
    preg_match($pattern, $html, $result);
    $version = $result[1];
  }
?>

<!DOCTYPE html>
<html lang="ja">
<head>
<meta charset="utf-8">
<title>一般ユーザ用TOP画面</title>
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<link rel="stylesheet" href="common.css">
<meta http-equiv="refresh" content="5">
</head>

<body>
  <header>
    <h1>見守りカメラ</h1>
  </header>

  <div id="content">
    <aside>
      <h2>メニュー</h2>
      <ul>
        <li>■ カメラ映像</li>
        <li><a href="album.php">■ アルバム</a></li>
        <li><a href="login1.php">■ 管理者用</a></li>
      </ul>
    </aside>
    <main>
      <h2>■ カメラ映像</h2>
      <div class=pic>
        <img src="images/now.jpg" width="100%" >
      </div> 
    </main>
  </div>
<br>
<hr>
<div>
  version：<?php echo $version; ?>
</div>
<div>
  接続元IPアドレス：<?php echo $from_ip; ?>
</div>
<div>
  接続元ホスト：<?php echo $from_host; ?>
</div>
<div>
  接続元ユーザエージェント：<?php echo $from_agent; ?>
</div>
</body>
</html>