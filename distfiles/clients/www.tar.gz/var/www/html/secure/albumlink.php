<?php
  // バージョン情報
  $html = file_get_contents("index.html");
  $version = "情報なし";
  if($html) {
    $pattern = '/<version>(.*)<\/version>/';
    preg_match($pattern, $html, $result);
    $version = $result[1];
  }

  // 表示対象のファイル名
  $filename = "";
  if(isset($_GET['filename'])) {
    // 脆弱性ポイント：ディレクトリ・トラバーサル。
    // 　　　　　　　　ファイル名を外部から直接指定することができる上、パスをチェックしていない。
    // 修正アドバイス：ファイル名を直接指定させない。指定させる場合はディレクトリを固定する。
    //$filename = $_GET['filename'];

    // 修正サンプル(メモ：ファイルを数字などで間接的に指定させる仕組みにするとより良い)
    $filename = basename($_GET['filename']);
  }

?>

<!DOCTYPE html>
<html lang="ja">
<head>
<meta charset="utf-8">
<title>一般ユーザ用アルバム画像参照画面</title>
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<link rel="stylesheet" href="common.css">
</head>

<body>
  <header>
    <h1>見守りカメラ</h1>
  </header>

  <div id="content">
    <aside>
      <h2>メニュー</h2>
      <ul>
        <li><a href="webcam.php">■ カメラ映像</a></li>
        <li><a href="album.php">■ アルバム</a></li>
        <li><a href="login1.php">■ 管理者用</a></li>
      </ul>
    </aside>

	<main>
      <h2>■ アルバム＞画像ファイル：<?php echo $filename; ?></h2>
      <div class=submenu>
        ファイル名変更：
        <form method="POST" action="album.php" style="display: inline;">
          <input type="text" name="new_name" >
		  <input type="hidden" name="now_name" value="<?php echo $filename; ?>">
          <input type="submit" name="dist" value="変更">
		  <div class=notice>※ファイル名を変更したらアルバムに戻ります</a>
        </form>
      </div>
      <div class=pic>
	
    <?php 
		  $base64_data = base64_encode(file_get_contents('album/'.$filename));
		  $finfo = new finfo(FILEINFO_MIME_TYPE);
	    $mime_type = $finfo->file('album/'.$filename);
		  echo "<object data=\"data:{$mime_type};base64,{$base64_data}\" width=\"500\"></object>";
		?>
      </div>
    </main>
  </div>

<br>
<hr>
<div>
  version：<?php echo $version; ?>
</div>
</body>
</html>