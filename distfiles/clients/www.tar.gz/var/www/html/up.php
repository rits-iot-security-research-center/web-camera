<?php
	require_once("login1.php");
	session_start();



	$db = new SQLite3('/var/www/db/user1.db');
	$data= "SELECT * FROM user WHERE id = \"".$_POST["username"]."\" AND passwd = \"".$_POST["password"]."\"";

	$result = $db->query($data);
	$result1 = $result->fetchArray();

	//print_r($result1);
	//print($result1['id'].$result1['passwd']);

	if($result1 == NULL){
	?>
<p style="color: red;">ユーザ名またはパスワードが違います</p>
<a href="login1.php"></a>

<?php	
	exit;
	}
	else{
	?>
ログインしました: 
<meta http-equiv="refresh"content="0;URL=update.php">
<a href="update.php">自動遷移しない場合はここをクリックしてください</a>
<?php 

      $_SESSION['username'] = $_POST["username"];
      $_SESSION['password'] = $_POST["password"];

//ログイン先ページへは現在リダイレクトで処理していますが、以下のheaderの変更で実装しようと試みてます
//http_response_code(301);   
//header("Location:update.php");
	exit;
	}    
?>


