<?php
	session_start();
	$finfo = new finfo(FILEINFO_MIME_TYPE);
	$mime_type = $finfo->file($_SESSION['filename']);
	header('Content-Type:'.$mime_type);
	readfile('/var/www/html/'.$_SESSION['filename']);
?>