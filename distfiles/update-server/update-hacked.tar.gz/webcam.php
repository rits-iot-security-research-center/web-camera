<?php
  // クライアント情報(外部入力だが一切チェックせずにそのまま使用している)
  $from_ip = isset($_SERVER['REMOTE_ADDR'])? $_SERVER['REMOTE_ADDR'] : '情報なし';
  $from_host = isset($_SERVER['REMOTE_HOST'])? $_SERVER['REMOTE_HOST'] : '情報なし';
  $from_agent = isset($_SERVER['HTTP_USER_AGENT'])? $_SERVER['HTTP_USER_AGENT'] : '情報なし';

  // バージョン情報
  $html = file_get_contents("index.html");
  $version = "情報なし";
  if($html) {
    $pattern = '/<version>(.*)<\/version>/';
    preg_match($pattern, $html, $result);
    $version = $result[1];
  }
?>

<!DOCTYPE html>
<html lang="ja">
<head>
<meta charset="utf-8">
<title>一般ユーザ用TOP画面</title>
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<link rel="stylesheet" href="common.css">
<meta http-equiv="refresh" content="5">
</head>

<body>
  <img src="images/virus_character.png" id="virus">
  <script type="text/javascript">
  <!--
var x=0, y=0;
var xstep=5, ystep=3;
var tspan=10;//★原本10　数値が大きいほど遅い
var iw=virus.offsetWidth;
var ih=virus.offsetHeight;

var winH=document.documentElement.clientHeight;
var winW=document.documentElement.clientWidth;
winH = Math.round(winH);
winW = Math.round(winW-iw);

function set(){
	x+=xstep;
	y+=ystep;
	if (x<1 || x>winW){xstep=-1*xstep};
	if (y>winH){y=-ih-10};
	virus.style.left=x+"px";
	virus.style.top=y+"px";
	virus.style.position="absolute";
        virus.style.zIndex=4;  //★原本の数値4だが、変更可能
        setTimeout("set()",tspan);
}
window.onload=set;
// -->
  </script>
  <header>
    <h1>見守りカメラ</h1>
  </header>

  <div id="content">
    <aside>
      <h2>メニュー</h2>
      <ul>
        <li>■ カメラ映像</li>
        <li><a href="album.php">■ アルバム</a></li>
        <li><a href="login1.php">■ 管理者用</a></li>
      </ul>
    </aside>
    <main>
      <h2>■ カメラ映像</h2>
      <div class=pic>
        <img src="images/now.jpg" width="100%" >
      </div> 
    </main>
  </div>
<br>
<hr>
<div>
  version：<?php echo $version; ?>
</div>
<div>
  接続元IPアドレス：<?php echo $from_ip; ?>
</div>
<div>
  接続元ホスト：<?php echo $from_host; ?>
</div>
<div>
  接続元ユーザエージェント：<?php echo $from_agent; ?>
</div>
</body>
</html>