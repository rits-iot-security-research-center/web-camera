<?php
  // バージョン情報
  $html = file_get_contents("index.html");
  $version = "情報なし";
  if($html) {
    $pattern = '/<version>(.*)<\/version>/';
    preg_match($pattern, $html, $result);
    $version = $result[1];
  }

  // 表示メッセージ
  $message = "";

  // POSTで呼び出された時だけの処理
  if(($_SERVER['REQUEST_METHOD'] == 'POST') && (isset($_POST['dist']))) {
    // 「保存」ボタンが押されていた場合
    if($_POST['dist'] == "保存") {
      $name = date("Y_m_d_H:i:s");
	  exec("raspistill -t 1 -q 10  -o /var/www/html/secure/album/$name", $output, $return_code);
      $message = "撮影コマンドを実行しました。（ファイル名:{$name}）（終了コード:{$return_code}）<br>";
	}

	// 「変更」ボタンが押されていた場合
	// 　・変更前後のファイル名は、外部入力を一切チェックせずにそのまま使用している
	// 　・ファイル名変更はexecでOSコマンドを直接叩いている
	else if($_POST['dist'] == "変更") {
	  if((isset($_POST["now_name"])) && ($_POST["new_name"])) {
	    $newname = 'album/'.$_POST["new_name"];
	    $nowname = $_POST["now_name"];
	    $newname = $_POST["new_name"];
	    $cmd = 'mv album/'. escapeshellarg($nowname) . ' album/' . escapeshellarg($newname);
	    
	    exec($cmd, $output, $return_code);
	    $message = "画像のファイル名を{$nowname}から{$newname}に変更しました。（終了コード:{$return_code}）<br>";
	  } else {
	    $message = "ファイル名は変更されませんでした。<br>";
	  }
	}
  }
?>

<!DOCTYPE html>
<html lang="ja">
<head>
<meta charset="utf-8">
<title>一般ユーザ用アルバム画面</title>
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<link rel="stylesheet" href="common.css">
</head>

<body>
  <header>
    <h1>見守りカメラ</h1>
  </header>

  <div id="content">
    <aside>
      <h2>メニュー</h2>
      <ul>
        <li><a href="webcam.php">■ カメラ映像</a></li>
        <li>■ アルバム</li>
        <li><a href="login1.php">■ 管理者用</a></li>
      </ul>
    </aside>

	<main>
	  <h2>■ アルバム</h2>

	  <p class=message>
	    <?php echo $message; ?>
      </p>
      <div class=submenu>
	    写真を撮ってアルバムに追加保存する：
		<form method="POST" action="album.php" style="display: inline;">
          <input type="submit" name="dist" value="保存">
        </form>
      </div>

	  <div class=submenu>
        <ul id="filelist">
          保存済みの画像一覧（ファイル名をクリックすると画像が見られます）
          <li>-albumフォルダ/</li>
		  <?php
		    foreach(glob("album/*") as $filepath) {
				//echo "<li><a href=\"albumlink.php?filename=" . urlencode($filepath) . "\">" .basename($filepath) . "</a></li>";
				echo "<li>　<a href=\"albumlink3.php?filename=" . urlencode(basename($filepath)) . "\">" .basename($filepath) . "</a></li>";
			}
		  ?>
        </ul>
      </div>

    </main>
  </div>

<br>
<hr>
<div>
  version：<?php echo $version; ?>
</div>
</body>
</html>