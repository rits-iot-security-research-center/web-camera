<?php
  // ログイン済みであることを確認
  session_start();
  if(!isset($_SESSION['username'])) {
    header("Location: login1.php", TRUE, 302);
    exit;
  }

  // 表示メッセージ
  $msg_ftp = "";
  $msg_download = "";
  $disp_firm = FALSE;

  if($_SERVER['REQUEST_METHOD'] == 'POST') {
    // FTPアップロードボタンが押された時の処理
    if(isset($_POST['ftp'])) {
      exec("/var/www/scripts/upload.sh", $output, $return_var);
      $msg_ftp = "FTPを実行しました。（終了コード:{$return_var}）";
    }

    // ファーム1ダウンロードボタンが押された時の処理
    if(isset($_POST['update1'])) {
      exec("/var/www/scripts/update-secure.sh", $output, $return_var);
      if($return_var == 0) {
        $msg_download = "ファームウェアを更新しました。（終了コード:{$return_var}）";
      } else if ($return_var <= 100) {
        $msg_download = "バージョン番号が取得できませんでした。（終了コード:{$return_var}）";
      } else if ($return_var <= 150) {
        $msg_download = "最新版です。更新の必要はありません。（終了コード:{$return_var}）";
      } else if ($return_var <= 200) {
        $msg_download = "ファームウェアのダウンロードに失敗しました。（終了コード:{$return_var}）";
      } else if ($return_var <= 250) {
        $msg_download = "ファームウェアの更新に失敗しました。（終了コード:{$return_var}）";
      }
    }
  }
?>

<!DOCTYPE html>
<html lang="ja">
<head>
<meta charset="utf-8">
<title>管理画面</title>
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<link rel="stylesheet" href="common.css">
</head>

<body>
  <header class=admin>
    <h1>管理者用ページ</h1>
  </header>

  <div>
    <h2 class=admin>■ クラウドストレージ</h2>
    <p class=message>
	  <?php echo $msg_ftp; ?>
    </p>
    <div class=submenu>
      クラウドサーバに現在の画像をFTPアップロードしますか？：
      <form method="POST" action="update.php" style="display: inline;">
        <input type="submit" name="ftp" value="はい">
      </form>
    </div>

    <h2 class=admin>■ ファームウェアアップデート</h2>
    <p class=message>
	  <?php echo $msg_download; ?>
    </p>
    <div class=submenu>
      ファームウェアをダウンロードしますか？：
      <form method="POST" action="update.php" style="display: inline;">
        <input type="submit" name="update1" value="はい">
      </form>
    </div>

    <div class=submenu>
      <ul id="filelist">
        ファームウェア取得元「https://iotserver.example.jp/download」<br>
        ダウンロード完了後、自動で展開されます。
      </ul>
    </div>

    <br>
    <hr>
    <div class=submenu>
      <a href="logout.php">ログアウトして一般用のページに戻る</a>
    </div>
  </div>
</body>
</html>
